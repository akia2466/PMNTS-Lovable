
      UPDATE assignments
      SET 
        title = {{params.title}},
        class_name = {{params.className}},
        description = {{params.description}},
        due_date = {{params.dueDate}}::date,
        updated_at = NOW()
      WHERE id = {{params.assignmentId}}::bigint
      RETURNING id, title, class_name, description, due_date;
    