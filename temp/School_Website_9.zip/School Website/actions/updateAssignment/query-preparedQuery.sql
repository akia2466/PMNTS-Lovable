
      UPDATE assignments
      SET 
        title = :param0,
        class_name = :param1,
        description = :param2,
        due_date = :param3::date,
        updated_at = NOW()
      WHERE id = :param4::bigint
      RETURNING id, title, class_name, description, due_date;
    