
      DELETE FROM announcements
      WHERE id = :param0::bigint;
    