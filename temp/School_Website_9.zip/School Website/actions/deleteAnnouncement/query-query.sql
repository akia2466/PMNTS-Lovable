
      DELETE FROM announcements
      WHERE id = {{params.announcementId}}::bigint;
    