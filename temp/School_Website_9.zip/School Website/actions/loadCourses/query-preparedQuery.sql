
      SELECT * FROM courses
      WHERE
        COALESCE(:param0, '') = '' 
        OR grade_level = :param1
      ORDER BY name;
    