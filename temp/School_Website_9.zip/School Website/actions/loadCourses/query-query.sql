
      SELECT * FROM courses
      WHERE
        COALESCE({{params.gradeLevel}}, '') = '' 
        OR grade_level = {{params.gradeLevel}}
      ORDER BY name;
    