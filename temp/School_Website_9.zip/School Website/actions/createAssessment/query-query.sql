
      INSERT INTO assessments (
        student_id, subject, assessment_type, assessment_date,
        score, max_score, percentage, grade, term, year
      )
      VALUES (
        {{params.studentId}}::bigint,
        {{params.subject}},
        {{params.assessmentType}},
        {{params.assessmentDate}}::date,
        {{params.score}}::numeric,
        {{params.maxScore}}::numeric,
        {{params.percentage}}::numeric,
        {{params.grade}},
        {{params.term}},
        {{params.year}}::integer
      )
      RETURNING *;
    