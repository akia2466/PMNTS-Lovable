
      INSERT INTO assessments (
        student_id, subject, assessment_type, assessment_date,
        score, max_score, percentage, grade, term, year
      )
      VALUES (
        :param0::bigint,
        :param1,
        :param2,
        :param3::date,
        :param4::numeric,
        :param5::numeric,
        :param6::numeric,
        :param7,
        :param8,
        :param9::integer
      )
      RETURNING *;
    