
      INSERT INTO attendance (student_id, date, status, term, year)
      VALUES (:param0::bigint, :param1::date, :param2, :param3, :param4::int)
      ON CONFLICT (student_id, date) 
      DO UPDATE SET status = :param5
      RETURNING id, student_id, date, status, term, year;
    