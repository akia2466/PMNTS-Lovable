
      INSERT INTO attendance (student_id, date, status, term, year)
      VALUES ({{params.studentId}}::bigint, {{params.date}}::date, {{params.status}}, {{params.term}}, {{params.year}}::int)
      ON CONFLICT (student_id, date) 
      DO UPDATE SET status = {{params.status}}
      RETURNING id, student_id, date, status, term, year;
    