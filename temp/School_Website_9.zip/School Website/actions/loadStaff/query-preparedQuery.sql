
      SELECT 
        s.id,
        s.user_id,
        s.department,
        s.position,
        s.hire_date,
        s.staff_id_number,
        u.name,
        u.email
      FROM staff s
      JOIN users u ON s.user_id = u.id
      ORDER BY u.name;
    