
      INSERT INTO assignments (staff_id, title, class_name, description, posted_date, due_date, total_students, submitted_count)
      VALUES ({{params.staffId}}::bigint, {{params.title}}, {{params.className}}, {{params.description}}, {{params.postedDate}}::date, {{params.dueDate}}::date, {{params.totalStudents}}::int, {{params.submittedCount}}::int)
      RETURNING id, staff_id, title, class_name, description, posted_date, due_date, total_students, submitted_count;
    