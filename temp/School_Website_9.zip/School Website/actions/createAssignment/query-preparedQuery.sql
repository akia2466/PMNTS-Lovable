
      INSERT INTO assignments (staff_id, title, class_name, description, posted_date, due_date, total_students, submitted_count)
      VALUES (:param0::bigint, :param1, :param2, :param3, :param4::date, :param5::date, :param6::int, :param7::int)
      RETURNING id, staff_id, title, class_name, description, posted_date, due_date, total_students, submitted_count;
    