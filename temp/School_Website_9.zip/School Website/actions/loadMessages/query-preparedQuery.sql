
      SELECT 
        m.id,
        m.sender_id,
        m.recipient_id,
        m.content,
        m.sent_at,
        m.read_at,
        sender.name as sender_name,
        recipient.name as recipient_name
      FROM messages m
      JOIN users sender ON m.sender_id = sender.id
      JOIN users recipient ON m.recipient_id = recipient.id
      WHERE 
        m.sender_id = :param0::bigint 
        OR m.recipient_id = :param1::bigint
      ORDER BY m.sent_at DESC;
    