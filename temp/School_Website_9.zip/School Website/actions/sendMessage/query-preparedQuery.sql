
      INSERT INTO messages (sender_id, recipient_id, content)
      VALUES (:param0::bigint, :param1::bigint, :param2)
      RETURNING id, sender_id, recipient_id, content, sent_at;
    