
      INSERT INTO messages (sender_id, recipient_id, content)
      VALUES ({{params.senderId}}::bigint, {{params.recipientId}}::bigint, {{params.content}})
      RETURNING id, sender_id, recipient_id, content, sent_at;
    