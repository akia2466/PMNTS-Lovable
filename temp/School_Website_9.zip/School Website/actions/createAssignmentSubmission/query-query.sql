
      INSERT INTO assignment_submissions (
        assignment_id, student_id, file_name, file_url
      )
      VALUES (
        {{params.assignmentId}}::bigint,
        {{params.studentId}}::bigint,
        {{params.fileName}},
        {{params.fileUrl}}
      )
      ON CONFLICT (assignment_id, student_id) 
      DO UPDATE SET
        file_name = {{params.fileName}},
        file_url = {{params.fileUrl}},
        submitted_at = NOW()
      RETURNING *;
    