
      INSERT INTO assignment_submissions (
        assignment_id, student_id, file_name, file_url
      )
      VALUES (
        :param0::bigint,
        :param1::bigint,
        :param2,
        :param3
      )
      ON CONFLICT (assignment_id, student_id) 
      DO UPDATE SET
        file_name = :param4,
        file_url = :param5,
        submitted_at = NOW()
      RETURNING *;
    