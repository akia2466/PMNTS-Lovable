
      UPDATE users
      SET 
        name = {{params.name}},
        role = {{params.role}},
        updated_at = NOW()
      WHERE id = {{params.userId}}::bigint
      RETURNING id, email, name, role;
    