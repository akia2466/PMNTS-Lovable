
      UPDATE users
      SET 
        name = :param0,
        role = :param1,
        updated_at = NOW()
      WHERE id = :param2::bigint
      RETURNING id, email, name, role;
    