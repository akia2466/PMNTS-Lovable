
      INSERT INTO announcements (title, content, author_id, target_audience, status)
      VALUES (:param0, :param1, :param2::bigint, :param3, :param4)
      RETURNING id, title, content, author_id, target_audience, status, created_at;
    