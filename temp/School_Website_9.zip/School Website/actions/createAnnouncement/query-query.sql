
      INSERT INTO announcements (title, content, author_id, target_audience, status)
      VALUES ({{params.title}}, {{params.content}}, {{params.authorId}}::bigint, {{params.targetAudience}}, {{params.status}})
      RETURNING id, title, content, author_id, target_audience, status, created_at;
    