
      SELECT 
        a.id, 
        a.title, 
        a.content, 
        a.author_id, 
        a.target_audience, 
        a.status, 
        a.created_at,
        a.updated_at,
        u.name as author_name
      FROM announcements a
      JOIN users u ON a.author_id = u.id
      WHERE 
        COALESCE({{params.status}}, '') = ''
        OR a.status = {{params.status}}
      ORDER BY a.created_at DESC;
    