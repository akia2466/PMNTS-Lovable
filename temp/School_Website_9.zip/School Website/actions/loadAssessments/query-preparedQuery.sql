
      SELECT 
        a.*,
        s.student_id_number,
        u.name as student_name
      FROM assessments a
      JOIN students s ON a.student_id = s.id
      JOIN users u ON s.user_id = u.id
      WHERE
        (COALESCE(:param0, 0) = 0 OR a.student_id = :param1::bigint)
        AND (COALESCE(:param2, '') = '' OR a.subject = :param3)
        AND (COALESCE(:param4, '') = '' OR a.term = :param5)
      ORDER BY a.assessment_date DESC;
    