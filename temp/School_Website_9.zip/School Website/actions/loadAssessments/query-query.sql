
      SELECT 
        a.*,
        s.student_id_number,
        u.name as student_name
      FROM assessments a
      JOIN students s ON a.student_id = s.id
      JOIN users u ON s.user_id = u.id
      WHERE
        (COALESCE({{params.studentId}}, 0) = 0 OR a.student_id = {{params.studentId}}::bigint)
        AND (COALESCE({{params.subject}}, '') = '' OR a.subject = {{params.subject}})
        AND (COALESCE({{params.term}}, '') = '' OR a.term = {{params.term}})
      ORDER BY a.assessment_date DESC;
    