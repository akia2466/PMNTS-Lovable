
      SELECT id, email, name, role
      FROM users
      WHERE email = :param0
      LIMIT 1;
    