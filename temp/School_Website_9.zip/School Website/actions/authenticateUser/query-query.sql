
      SELECT id, email, name, role
      FROM users
      WHERE email = {{params.email}}
      LIMIT 1;
    