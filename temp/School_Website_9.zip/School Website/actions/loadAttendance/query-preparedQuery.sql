
      SELECT 
        a.id,
        a.student_id,
        a.date,
        a.status,
        a.term,
        a.year,
        s.student_id_number,
        u.name as student_name
      FROM attendance a
      JOIN students s ON a.student_id = s.id
      JOIN users u ON s.user_id = u.id
      WHERE 
        (:param0 IS NULL OR a.student_id = :param1::bigint)
        AND (:param2 IS NULL OR a.term = :param3)
        AND (:param4 IS NULL OR a.year = :param5::int)
      ORDER BY a.date DESC;
    