
      SELECT 
        a.id,
        a.student_id,
        a.date,
        a.status,
        a.term,
        a.year,
        s.student_id_number,
        u.name as student_name
      FROM attendance a
      JOIN students s ON a.student_id = s.id
      JOIN users u ON s.user_id = u.id
      WHERE 
        ({{params.studentId}} IS NULL OR a.student_id = {{params.studentId}}::bigint)
        AND ({{params.term}} IS NULL OR a.term = {{params.term}})
        AND ({{params.year}} IS NULL OR a.year = {{params.year}}::int)
      ORDER BY a.date DESC;
    