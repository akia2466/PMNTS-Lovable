
      DELETE FROM users
      WHERE id = {{params.userId}}::bigint;
    