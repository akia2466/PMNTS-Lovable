
      DELETE FROM users
      WHERE id = :param0::bigint;
    