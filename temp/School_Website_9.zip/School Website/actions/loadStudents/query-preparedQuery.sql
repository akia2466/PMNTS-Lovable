
      SELECT 
        s.id,
        s.user_id,
        s.grade_level,
        s.enrollment_date,
        s.student_id_number,
        u.name,
        u.email
      FROM students s
      JOIN users u ON s.user_id = u.id
      ORDER BY u.name;
    