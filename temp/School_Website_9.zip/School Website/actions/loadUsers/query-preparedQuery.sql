
      SELECT id, email, name, role, created_at, updated_at
      FROM users
      ORDER BY created_at DESC;
    