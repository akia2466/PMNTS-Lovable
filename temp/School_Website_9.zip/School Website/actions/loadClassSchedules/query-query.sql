
      SELECT 
        cs.*,
        c.name as course_name,
        c.code as course_code,
        u.name as teacher_name
      FROM class_schedules cs
      JOIN courses c ON cs.course_id = c.id
      JOIN staff st ON cs.staff_id = st.id
      JOIN users u ON st.user_id = u.id
      WHERE
        (COALESCE({{params.staffId}}, 0) = 0 OR cs.staff_id = {{params.staffId}}::bigint)
        AND (COALESCE({{params.term}}, '') = '' OR cs.term = {{params.term}})
      ORDER BY 
        CASE cs.day_of_week
          WHEN 'Monday' THEN 1
          WHEN 'Tuesday' THEN 2
          WHEN 'Wednesday' THEN 3
          WHEN 'Thursday' THEN 4
          WHEN 'Friday' THEN 5
        END,
        cs.start_time;
    