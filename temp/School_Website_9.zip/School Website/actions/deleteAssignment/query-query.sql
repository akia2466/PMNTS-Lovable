
      DELETE FROM assignments
      WHERE id = {{params.assignmentId}}::bigint;
    