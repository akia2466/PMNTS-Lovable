
      DELETE FROM assignments
      WHERE id = :param0::bigint;
    