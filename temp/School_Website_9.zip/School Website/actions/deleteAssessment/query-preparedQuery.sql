
      DELETE FROM assessments
      WHERE id = :param0::bigint;
    