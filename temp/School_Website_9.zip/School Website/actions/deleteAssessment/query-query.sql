
      DELETE FROM assessments
      WHERE id = {{params.id}}::bigint;
    