
      SELECT 
        asub.*,
        s.student_id_number,
        u.name as student_name,
        a.title as assignment_title
      FROM assignment_submissions asub
      JOIN students s ON asub.student_id = s.id
      JOIN users u ON s.user_id = u.id
      JOIN assignments a ON asub.assignment_id = a.id
      WHERE
        (COALESCE({{params.assignmentId}}, 0) = 0 OR asub.assignment_id = {{params.assignmentId}}::bigint)
        AND (COALESCE({{params.studentId}}, 0) = 0 OR asub.student_id = {{params.studentId}}::bigint)
      ORDER BY asub.submitted_at DESC;
    