
      INSERT INTO users (email, password_hash, name, role)
      VALUES ({{params.email}}, {{params.passwordHash}}, {{params.name}}, {{params.role}})
      RETURNING id, email, name, role;
    