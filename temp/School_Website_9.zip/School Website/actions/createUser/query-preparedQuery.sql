
      INSERT INTO users (email, password_hash, name, role)
      VALUES (:param0, :param1, :param2, :param3)
      RETURNING id, email, name, role;
    