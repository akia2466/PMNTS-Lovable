
      SELECT 
        a.id,
        a.staff_id,
        a.title,
        a.class_name,
        a.description,
        a.posted_date,
        a.due_date,
        a.total_students,
        a.submitted_count,
        a.created_at,
        u.name as teacher_name
      FROM assignments a
      JOIN staff s ON a.staff_id = s.id
      JOIN users u ON s.user_id = u.id
      WHERE 
        {{params.staffId}} IS NULL OR a.staff_id = {{params.staffId}}::bigint
      ORDER BY a.posted_date DESC;
    