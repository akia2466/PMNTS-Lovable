
      UPDATE assessments
      SET
        score = {{params.score}}::numeric,
        max_score = {{params.maxScore}}::numeric,
        percentage = {{params.percentage}}::numeric,
        grade = {{params.grade}},
        updated_at = NOW()
      WHERE id = {{params.id}}::bigint
      RETURNING *;
    