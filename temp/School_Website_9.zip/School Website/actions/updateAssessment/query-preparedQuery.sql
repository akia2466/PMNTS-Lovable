
      UPDATE assessments
      SET
        score = :param0::numeric,
        max_score = :param1::numeric,
        percentage = :param2::numeric,
        grade = :param3,
        updated_at = NOW()
      WHERE id = :param4::bigint
      RETURNING *;
    