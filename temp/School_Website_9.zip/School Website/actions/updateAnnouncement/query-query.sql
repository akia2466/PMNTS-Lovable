
      UPDATE announcements
      SET 
        title = {{params.title}},
        content = {{params.content}},
        target_audience = {{params.targetAudience}},
        status = {{params.status}},
        updated_at = NOW()
      WHERE id = {{params.announcementId}}::bigint
      RETURNING id, title, content, target_audience, status;
    