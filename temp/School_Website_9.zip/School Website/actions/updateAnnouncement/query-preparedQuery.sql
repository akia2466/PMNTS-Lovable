
      UPDATE announcements
      SET 
        title = :param0,
        content = :param1,
        target_audience = :param2,
        status = :param3,
        updated_at = NOW()
      WHERE id = :param4::bigint
      RETURNING id, title, content, target_audience, status;
    